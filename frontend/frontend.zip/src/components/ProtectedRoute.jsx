import { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { apiFetch } from 'csrfClient';

const API = import.meta.env.VITE_API_URL;

export default function ProtectedRoute({ children }) {
  const [state, setState] = useState({ loading: true, ok: false });

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();

    (async () => {
      try {
        const res = await apiFetch(`${API}/auth/session`, {
          credentials: 'include',
          signal: controller.signal,
        });
        if (!cancelled) setState({ loading: false, ok: res.ok });
      } catch (e) {
        if (!cancelled) setState({ loading: false, ok: false });
      }
    })();

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, []);

  if (state.loading) {
    // simple inline loader so “blank page” becomes obviously loading
    return (
      <div style={{display:'grid',placeItems:'center',height:'60vh',fontFamily:'sans-serif'}}>
        Checking session…
      </div>
    );
  }

  if (!state.ok) return <Navigate to="/" replace />;
  return children;
}
