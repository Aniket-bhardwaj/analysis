// src/csrfClient.js
let csrfToken = null;

export async function ensureCsrf() {
  if (csrfToken) return csrfToken;
  const r = await fetch('/api/csrf', { credentials: 'include' });
  const j = await r.json();
  csrfToken = j.csrfToken;
  return csrfToken;
}

export async function apiFetch(url, options = {}) {
  const method = (options.method || 'GET').toUpperCase();
  const needs = !['GET','HEAD','OPTIONS'].includes(method);
  const headers = new Headers(options.headers || {});
  const opts = { credentials: 'include', ...options, headers };

  if (needs) {
    headers.set('X-CSRF-Token', await ensureCsrf());
    // If body is FormData, let the browser set the multipart boundary
    const isFormData = options?.body instanceof FormData;
    if (!isFormData && !headers.has('Content-Type')) {
      headers.set('Content-Type', 'application/json');
    }
  }

  return fetch(url, opts);
}
